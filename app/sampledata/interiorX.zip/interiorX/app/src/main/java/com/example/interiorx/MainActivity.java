package com.example.interiorx;

import androidx.appcompat.app.AppCompatActivity;

import android.app.MediaRouteButton;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.transition.ArcMotion;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.ar.core.ArCoreApk;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    private MediaRouteButton mArButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean isFirstRun = getSharedPreferences("PREFERENCE", MODE_PRIVATE)
                .getBoolean("isFirstRun", true);
        if (isFirstRun) {
            startActivity(new Intent(MainActivity.this,Boarding.class));
            finish();
        }
        getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit()
                .putBoolean("isFirstRun", false).commit();

        setContentView(R.layout.activity_main);
        bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setBackground(null);

//        maybeEnableArButton();


    }
//    void maybeEnableArButton(){
//        ArCoreApk.Availability availability= ArCoreApk.getInstance().checkAvailability(this);
//        if(availability.isTransient()){
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    maybeEnableArButton();
//
//                }
//            },200);
//        }
//
//        if(availability.isSupported()){
//            mArButton.setVisibility(View.VISIBLE);
//            mArButton.setEnabled(true);
//        }else{
//            mArButton.setVisibility(View.INVISIBLE);
//            mArButton.setEnabled(false);
//        }
//    }

}








