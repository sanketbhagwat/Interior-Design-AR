package com.example.interiorx;

public class onboardingItems {
    int imageId;
    String heading,description;
    public onboardingItems(int imageId,String heading,String description){
        this.imageId=imageId;
        this.heading=heading;
        this.description=description;
    }


}
